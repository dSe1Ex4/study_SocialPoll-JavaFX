package stdy.socialPoll.gateways;

import stdy.socialPoll.models.Question;

public class QuestionGateway extends GatewayDefault<Question> {
    public QuestionGateway(){
        insert(new Question("С кем бы ты хотел сидеть за одним столом? Выбери себе до 3-х человек."));
        insert(new Question("Представь, что тебе на День рождения подарили 4 билета в цирк. Один билет тебе, у тебя остается 3 билета. Кого бы ты хотел пригласить с собой в цирк?"));
        insert(new Question("С кем бы ты хотел пойти погулять на улицу? Выбери из группы 3 человека."));
        insert(new Question("С кем бы ты поешл играть в прятки? Выбери себе до 3-х человек."));
        insert(new Question("С кем бы ты хотел отправится в поход? Выбери себе до 3-х человек."));
    }
}
