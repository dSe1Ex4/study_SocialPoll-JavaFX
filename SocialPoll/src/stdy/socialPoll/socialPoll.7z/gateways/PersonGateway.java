package stdy.socialPoll.gateways;

import stdy.socialPoll.models.Person;

public class PersonGateway extends GatewayDefault<Person> {
    public PersonGateway() {
        insert(new Person(1, "Gaga", "Baba", "Obob"));
        insert(new Person(2, "Gaga2", "Baba2", "Obob2"));
        insert(new Person(3, "Gaga3", "Baba3", "Obob3"));
        insert(new Person(4, "Gaga4", "Baba4", "Obob4"));
    }
}